export const DEFAULTS = {name:'',signature:'',timezone:'Asia/Oral',notify:'all',quietStart:'22:00',quietEnd:'08:00',quiet:false,privateNotifications:true,retention:90,undoSeconds:15,templates:[{name:'Встреча',subject:'Встреча',body:'Привет!\n\nПредлагаю встретиться в удобное для тебя время. Когда получится?'},{name:'Документы',subject:'Документы',body:'Здравствуйте!\n\nОтправляю документы во вложении. Буду рад обратной связи.'}]};
export const b64 = v => Buffer.from(v).toString('base64url');
export const random = () => b64(crypto.getRandomValues(new Uint8Array(32)));
export const hash = async v => b64(await crypto.subtle.digest('SHA-256',new TextEncoder().encode(v)));
export async function seal(value,key){const iv=crypto.getRandomValues(new Uint8Array(12));const k=await crypto.subtle.importKey('raw',Buffer.from(key,'base64url'),'AES-GCM',false,['encrypt']);return b64(iv)+'.'+b64(await crypto.subtle.encrypt({name:'AES-GCM',iv},k,new TextEncoder().encode(JSON.stringify(value))));}
export async function unseal(value,key){const [iv,data]=value.split('.');const k=await crypto.subtle.importKey('raw',Buffer.from(key,'base64url'),'AES-GCM',false,['decrypt']);return JSON.parse(new TextDecoder().decode(await crypto.subtle.decrypt({name:'AES-GCM',iv:Buffer.from(iv,'base64url')},k,Buffer.from(data,'base64url'))));}
export function escapeHtml(s){return String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));}
export function formattedText(value){return escapeHtml(value).replace(/\*\*([^*\n]+)\*\*/g,'<strong>$1</strong>').replace(/\*([^*\n]+)\*/g,'<em>$1</em>').replace(/\n/g,'<br>');}
export function validateMail(p){
 if(!p||typeof p.to!=='string'||!/^([^\s<>@,;]+)@([^\s<>@,;]+)\.[^\s<>@,;]+$/.test(p.to)||/[\r\n]/.test(p.to))throw new Error('Укажите один корректный адрес получателя.');
 for(const key of ['subject','body'])if(typeof p[key]!=='string')throw new Error('Заполните тему и текст.');
 if(!p.subject.trim()||p.subject.length>500||/[\r\n]/.test(p.subject))throw new Error('Проверьте тему письма (до 500 символов, без переносов).');
 if(p.body.length>200000)throw new Error('Слишком большой текст письма.');
 if(p.replyMessageId&&!/^<[^\s<>]+>$/.test(p.replyMessageId))throw new Error('Некорректный заголовок ответа.');
 if(p.threadId&&!/^[a-zA-Z0-9_-]+$/.test(p.threadId))throw new Error('Некорректная переписка.');
 if(!Array.isArray(p.attachments??[]))throw new Error('Некорректные вложения.');
 let size=0;
 for(const a of p.attachments??[]){if(typeof a.name!=='string'||a.name.length>255||/[\r\n]/.test(a.name)||typeof a.data!=='string'||!/^[A-Za-z0-9+/]*={0,2}$/.test(a.data))throw new Error('Некорректное вложение.');size+=a.data.length;}
 if(size>20*1024*1024)throw new Error('В этой сборке вложения ограничены примерно 15 МБ суммарно из-за памяти Worker.');
 return {...p,track:p.track!==false,notify:['all','first','off'].includes(p.notify)?p.notify:'all',attachments:p.attachments??[]};
}
function wrapped(v){return v.match(/.{1,76}/g)?.join('\r\n')||'';}
function part(type,content){return `Content-Type: ${type}; charset=UTF-8\r\nContent-Transfer-Encoding: base64\r\n\r\n${wrapped(Buffer.from(content).toString('base64'))}\r\n`;}
export function mime(p,{email,name,origin,token,id}){
 validateMail(p);if(/[\r\n]/.test(email))throw new Error('Invalid sender');
 const mixed='mixed_'+id,alt='alt_'+id;
 const encoded=s=>'=?UTF-8?B?'+Buffer.from(s).toString('base64')+'?=';
 const from=name?`${encoded(name)} <${email}>`:email;
 const html=`<div style="font-family:Arial,sans-serif;font-size:16px;line-height:1.5">${formattedText(p.body)}</div>`+(token?`<img src="${origin}/t/${token}.gif" width="1" height="1" alt="">`:'');
 let s=`From: ${from}\r\nTo: ${p.to}\r\nSubject: ${encoded(p.subject)}\r\nMessage-ID: <${id}@pulse-mail.local>\r\nMIME-Version: 1.0\r\n`;
 if(p.replyMessageId)s+=`In-Reply-To: ${p.replyMessageId}\r\nReferences: ${p.replyMessageId}\r\n`;
 s+=`Content-Type: multipart/mixed; boundary="${mixed}"\r\n\r\n--${mixed}\r\nContent-Type: multipart/alternative; boundary="${alt}"\r\n\r\n--${alt}\r\n`+part('text/plain',p.body)+`--${alt}\r\n`+part('text/html',html)+`--${alt}--\r\n`;
 for(const a of p.attachments){s+=`--${mixed}\r\nContent-Type: application/octet-stream\r\nContent-Disposition: attachment; filename*=UTF-8''${encodeURIComponent(a.name)}\r\nContent-Transfer-Encoding: base64\r\n\r\n${wrapped(a.data)}\r\n`;}
 return b64(s+`--${mixed}--\r\n`);
}
export function quietNow(s,now=Date.now()){
 if(!s.quiet)return false;const t=new Intl.DateTimeFormat('en-GB',{timeZone:s.timezone,hour:'2-digit',minute:'2-digit',hour12:false}).format(now);
 return s.quietStart<=s.quietEnd?t>=s.quietStart&&t<s.quietEnd:t>=s.quietStart||t<s.quietEnd;
}
export function pushEndpoint(endpoint){try{const u=new URL(endpoint);return u.protocol==='https:'&&!u.username&&!u.password&&!u.port&&(['fcm.googleapis.com','updates.push.services.mozilla.com','web.push.apple.com'].includes(u.hostname)||u.hostname.endsWith('.push.apple.com')||u.hostname.endsWith('.notify.windows.com'));}catch{return false;}}
