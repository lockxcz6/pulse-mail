# Included dependencies

- Lucide 0.468.0 — ISC license. https://lucide.dev/license
- DOMPurify 3.3.3 — Apache-2.0 OR MPL-2.0. https://github.com/cure53/DOMPurify
- web-push 3.6.7 — MIT. https://github.com/web-push-libs/web-push
- Wrangler and its build dependencies — see installed package licenses; not shipped as runtime client assets.

License texts for bundled browser assets and web-push are included in licenses/.
