import {cp,mkdir,writeFile,rm} from 'node:fs/promises';
const input=process.argv[2];if(!input)throw new Error('Использование: npm run netlify -- https://YOUR-WORKER.workers.dev');
const u=new URL(input);if(u.protocol!=='https:'||u.pathname!=='/'||u.search||u.hash)throw new Error('Нужен HTTPS-адрес Worker без пути.');
await mkdir('netlify-public',{recursive:true});await cp('public','netlify-public',{recursive:true});
await writeFile('netlify-public/_redirects',`/api/* ${u.origin}/api/:splat 200\n/auth/* ${u.origin}/auth/:splat 200\n/t/* ${u.origin}/t/:splat 200\n`);
console.log('Готово: загрузите папку netlify-public на Netlify. После этого смените APP_URL и OAuth redirect URI на адрес Netlify и снова выполните npm run deploy.');
