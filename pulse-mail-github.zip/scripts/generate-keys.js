import webpush from 'web-push';
import {randomBytes} from 'node:crypto';
const k=webpush.generateVAPIDKeys();
console.log('ENCRYPTION_KEY='+randomBytes(32).toString('base64url'));
console.log('VAPID_PUBLIC_KEY='+k.publicKey);
console.log('VAPID_PRIVATE_KEY='+k.privateKey);
console.log('\nСохраните секреты безопасно. Не добавляйте их в Git и не меняйте ENCRYPTION_KEY после подключения Gmail.');
