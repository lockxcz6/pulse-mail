import {createInterface} from 'node:readline/promises';
import {readFile,writeFile} from 'node:fs/promises';
const rl=createInterface({input:process.stdin,output:process.stdout});
try{
 const config=JSON.parse(await readFile(new URL('../wrangler.jsonc',import.meta.url),'utf8'));
 const db=(await rl.question('Database ID из команды wrangler d1 create: ')).trim();
 const email=(await rl.question('Ваш разрешённый Gmail: ')).trim().toLowerCase();
 const url=(await rl.question('Адрес приложения (https://pulse-mail....workers.dev), без / в конце: ')).trim().replace(/\/$/,'');
 if(!/^[0-9a-f-]{36}$/i.test(db))throw new Error('Неверный Database ID.');
 if(!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email))throw new Error('Неверный email.');
 const u=new URL(url);if(u.protocol!=='https:'||u.pathname!=='/'||u.search||u.hash)throw new Error('Нужен HTTPS-адрес без пути.');
 config.d1_databases[0].database_id=db;config.vars.ALLOWED_EMAIL=email;config.vars.APP_URL=u.origin;
 await writeFile(new URL('../wrangler.jsonc',import.meta.url),JSON.stringify(config,null,2)+'\n');
 console.log('Настройки сохранены. OAuth redirect URI: '+u.origin+'/auth/callback');
}catch(e){console.error(e.message);process.exitCode=1;}finally{rl.close();}
